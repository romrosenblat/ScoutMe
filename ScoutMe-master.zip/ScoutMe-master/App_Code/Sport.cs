﻿/// <summary>
/// Summary description for Sports
/// </summary>
public class Sports
{
    public Sports()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    int sportId;
    public int SportId
    {
        get { return sportId; }
        set { sportId = value; }
    }

    string sport;
    public string Sport
    {
        get { return sport; }
        set { sport = value; }
    }
}